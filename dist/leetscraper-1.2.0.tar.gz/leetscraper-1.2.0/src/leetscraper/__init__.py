from .leetscraper import Leetscraper

__version__ = "1.2.0"
__licence__ = "GPL-2.0"
__author__ = "Pavocracy"
__email__ = "pavocracy@pm.me"
