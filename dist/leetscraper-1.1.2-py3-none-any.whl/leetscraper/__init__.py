from .leetscraper import Leetscraper

__VERSION__ = "1.1.2"
__LICENSE__ = "GPL-2.0"
__AUTHOR__ = "Pavocracy"
__EMAIL__ = "pavocracy@pm.me"